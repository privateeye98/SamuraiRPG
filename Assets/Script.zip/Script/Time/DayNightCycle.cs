using UnityEngine;

[System.Serializable]
public class LayerGroup
{
    public string name;
    public Transform parent;               // BACKGROUND , MIDDLEGROUND
    public Gradient colorOverTime;        // �ð��� ���� ����
    [HideInInspector] public SpriteRenderer[] renderers;
}

public class DayNightCycle : MonoBehaviour
{

    public static float currentTime { get; private set; }

    public float cycleDuration = 60f;
    public LayerGroup[] layers;

    float timer;

    void Start()
    {
        foreach (var layer in layers)
        {
            if (layer.parent != null)
            {
                layer.renderers = layer.parent.GetComponentsInChildren<SpriteRenderer>();
            }
        }
    }

    void Update()
    {
        timer += Time.deltaTime;
        currentTime = timer;

        float t = (timer % cycleDuration) / cycleDuration;

        foreach (var layer in layers)
        {
            Color c = layer.colorOverTime.Evaluate(t);
            foreach (var sr in layer.renderers)
            {
                if (sr != null)
                    sr.color = c;
            }
        }
    }
}
