using UnityEngine;

  public enum QuestState
    {
        NotStarted,
        InProgress,
        Completed
    }
