using UnityEngine;
public class LogoShade : MonoBehaviour
{
    
}
