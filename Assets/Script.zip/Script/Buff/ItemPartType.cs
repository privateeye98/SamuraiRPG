public enum ItemType { Equipment, Consumable, Quest }

public enum ItemPartType
{
    Head = 0,
    Body = 1,
    Leg = 2,
    Shoe = 3,
    Glove = 4,
    Weapon = 5
}
