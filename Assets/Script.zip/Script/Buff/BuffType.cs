public enum BuffType
{
    StrengthUp,
    DexterityUp,
    CritUp,
    ExpUp,
    SpeedUp
}
